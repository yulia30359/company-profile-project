<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>company profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
      .img-fluid {
        width: 100%; 
        max-width: 500px; 
        float: right; 
        margin-left: 20px; 
      }
      .fade-up {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.5s ease, transform 0.5s ease;
}

.fade-up.active {
  opacity: 1;
  transform: translateY(0);
}

      
    </style>
  </head>
  <body>

  <!---Navbar-->
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark py-3">
        <div class="container">
          <a class="navbar-brand" href="#">IT Corp</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
              <a class="nav-link active" aria-current="page" href="#">Home</a>
              <a class="nav-link" href="#About">About</a>
              <a class="nav-link" href="#Layanan">Layanan</a>
              <a class="nav-link " href="#Portofolio">Portofolio</a>
              <a class="nav-link" href="#Team">Team</a>
              <a class="nav-link " href="#Contact">Contact</a>
              
            </div>
          </div>
        </div>
      </nav>

      <!-- HERO -->
<div class="container-fluid bg-light">
  <div class="container mt-5 p-5 bg-light">
    <div class="row align-items-center">
      <div class="col-md">
        <p class="h1">Selamat datang di IT Corp</p>
        <p>Teknologi yang Lebih Baik, Masa Depan yang Lebih Baik</p>
        <a id="About" class="btn btn-primary mt-5" href="#About">Get Started</a>

        <!-- Tambahkan Tombol Video -->
        <a href="https://youtu.be/fiuhu924--M?feature=shared" target="_blank" class="btn btn-success mt-5 bg-secondary">Tonton video</a>
        </button>

      </div>
      <div class="col-md">
        <img class="img-fluid" src="gambar/hero-img.png">
      </div>
    </div>
  </div>
</div>

      <!-- ======= About Us Section ======= -->
<section id="About" class="About bg-secondary">
  <div class="container" data-aos="fade-up bg-secondary">

    <div class="section-title p-5  text-center"> 
      <h2>About Us</h2>
    </div>

    <div class="row content">
      <div class="col-lg-6">
        <p>
          Perusahaan IT (Teknologi Informasi) modern seringkali menjadi motor penggerak inovasi dan transformasi digital. Sebuah perusahaan IT 
          berfokus pada pengembangan, implementasi, dan pemeliharaan solusi teknologi untuk memenuhi kebutuhan bisnis dan konsumen. 
        </p>
        <ul>
          <li><i class="ri-check-double-line"></i> Perusahaan IT juga berperan penting dalam mendukung transformasi digital bisnis</li>
          <li><i class="ri-check-double-line"></i> membantu organisasi untuk mengadopsi teknologi terbaru seperti kecerdasan buatan (AI)</li>
          <li><i class="ri-check-double-line"></i> Internet of Things (IoT), komputasi awan, dan blockchain. </li>
        </ul>
      </div>
      <div class="col-lg-6 pt-4 pt-lg-0">
        <p>
          Perusahaan IT biasanya terlibat dalam pengembangan perangkat lunak dan aplikasi, pembuatan dan pengelolaan infrastruktur jaringan, serta penyediaan layanan konsultasi teknologi. Mereka dapat bekerja pada proyek-proyek khusus seperti pengembangan sistem manajemen informasi, implementasi solusi e-commerce, pengembangan aplikasi mobile, dan pemeliharaan sistem keamanan.
        </p>
      </div>
    </div>

  </div>
</section><!-- End About Us Section -->

 <!-- ======= Why Us Section ======= -->
 <section id="why-us" class="why-us section-bg">
  <div class="container-fluid mt-5 p-5" data-aos="fade-up">

    <div class="row">

      <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

        <div class="content">
          <h3>Teknologi Informasi merujuk pada penggunaan komputer <strong> perangkat keras, perangkat lunak, dan sistem jaringan untuk menyimpan</strong></h3>
          <p>
            Memilih sebuah perusahaan di bidang Teknologi Informasi (IT) dapat menjadi keputusan yang sangat penting dan mempengaruhi karier serta pengalaman yang profesional
          </p>
        </div>

        <div class="accordion-list">
          <ul>
            <li>
              <a data-bs-toggle="collapse" class="collapse" data-bs-target="#accordion-list-1"><span>01</span> Non consectetur a erat nam at lectus urna duis? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-1" class="collapse show" data-bs-parent=".accordion-list">
                <p>
                  Perusahaan IT seringkali beroperasi di industri yang berkembang pesat. Sebagai hasilnya, mereka cenderung mendorong inovasi dan pertumbuhan, memberikan kesempatan bagi karyawan untuk terlibat dalam proyek-proyek baru dan mendapatkan pengalaman berharga.
                </p>
              </div>
            </li>

            <li>
              <a data-bs-toggle="collapse" class="collapse" data-bs-target="#accordion-list-1"><span>01</span> Feugiat scelerisque varius morbi enim nunc? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-1" class="collapse show" data-bs-parent=".accordion-list">
                    <p>
                      Industri IT menawarkan berbagai peluang karier di berbagai bidang seperti pengembangan perangkat lunak, analisis data, keamanan informasi, kecerdasan buatan, dan banyak lagi. Pilihlah perusahaan yang memberikan jalur karier jelas dan peluang pengembangan profesional.
                </p>
              </div>
            </li>

            <li>
              <a data-bs-toggle="collapse" class="collapse" data-bs-target="#accordion-list-1"><span>01</span> Dolor sit amet consectetur adipiscing elit? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-1" class="collapse show" data-bs-parent=".accordion-list">
                    <p>
                      Perusahaan IT sering mendorong budaya kerja kolaboratif dan tim. Tim yang terdiri dari individu dengan berbagai latar belakang dan keahlian dapat menciptakan lingkungan yang kreatif dan mendukung.
                </p>
              </div>
            </li>

          </ul>
        </div>

      </div>

      <div class="col-md">
        <img class="img-fluid" src="gambar/why-us.png" >
    </div>

  </div>
</section><!-- End Why Us Section -->
  

<!---Layanan-->
<div id="Layanan" class="container-fluid bg-dark">
  <div class="container mt-5 p-5 text-center bg-dark">
    <h3 class="card-subtitle mt-5 p-5 text-white">Layanan</h3>
  <div class="row text-center">
    <div class="col-md-4">
      <div class="card" style="width: 18rem;">
        <div class="card-body p-5">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" width="24" height="24">
            <!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path d="M320 464c8.8 0 16-7.2 16-16V160H256c-17.7 0-32-14.3-32-32V48H64c-8.8 0-16 7.2-16 16V448c0 8.8 7.2 16 16 16H320zM0 64C0 28.7 28.7 0 64 0H229.5c17 0 33.3 6.7 45.3 18.7l90.5 90.5c12 12 18.7 28.3 18.7 45.3V448c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V64z"/>
          </svg>
          <h5 class="card-title">Website</h5>
          <p class="card-text">Kami melayani pembuatan website responsive dengan teknologi terbaru serta menyediakan hosting dan domain dari web tersebut.</p>
          <a href="https://wa.me/6281287189874?text=Hello%20IT%20Corp,%20I%20Order20Now" target="_blank" class="btn btn-success mt-5 bg-primary">Get Started</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card" style="width: 18rem;">
        <div class="card-body p-5">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" width="24" height="24">
            <!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path d="M32 0C14.3 0 0 14.3 0 32S14.3 64 32 64V75c0 42.4 16.9 83.1 46.9 113.1L146.7 256 78.9 323.9C48.9 353.9 32 394.6 32 437v11c-17.7 0-32 14.3-32 32s14.3 32 32 32H64 320h32c17.7 0 32-14.3 32-32s-14.3-32-32-32V437c0-42.4-16.9-83.1-46.9-113.1L237.3 256l67.9-67.9c30-30 46.9-70.7 46.9-113.1V64c17.7 0 32-14.3 32-32s-14.3-32-32-32H320 64 32zM96 75V64H288V75c0 25.5-10.1 49.9-28.1 67.9L192 210.7l-67.9-67.9C106.1 124.9 96 100.4 96 75z"/>
          </svg>   
          <h5 class="card-title">Mobile</h5>
          <p class="card-text">Kami melayani pembuatan aplikasi Android dan juga IOS, yang dapat dikoneksikan ke dalam website suatu perusahaan yang kamu miliki</p>
          <a href="https://wa.me/6281287189874?text=Hello%20IT%20Corp,%20I%20Order%20Now" target="_blank" class="btn btn-success mt-5 bg-primary">Get Started</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card" style="width: 18rem;">
        <div class="card-body p-5">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="24" height="24">
            <!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path d="M96 0C43 0 0 43 0 96V416c0 53 43 96 96 96H384h32c17.7 0 32-14.3 32-32s-14.3-32-32-32V384c17.7 0 32-14.3 32-32V32c0-17.7-14.3-32-32-32H384 96zm0 384H352v64H96c-17.7 0-32-14.3-32-32s14.3-32 32-32zm32-240c0-8.8 7.2-16 16-16H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H144c-8.8 0-16-7.2-16-16zm16 48H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H144c-8.8 0-16-7.2-16-16s7.2-16 16-16z"/>
          </svg>  
          <h5 class="card-title">Desktop</h5>
          <p class="card-text">Kami melayani pembuatan aplikasi desktop yang dapat berjalan diberbagai sistem operasi seperti Windows, Mac OS, dan Linux</p>
          <a href="https://wa.me/6281287189874?text=Hello%20IT%20Corp,%20I%20Order%20Now" target="_blank" class="btn btn-success mt-5 bg-primary">Get Started</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ======= Portfolio Section ======= -->
<div id="Portofolio" class="container-fluid bg-light">
  <div class="container mt-5 p-5 text-center bg-light">
    <h3 class="card-subtitle mt-5 p-5 text-dark">Portofolio</h3>
    <div class="row text-center">
      <div class="col-md-4">
        <div class="card" style="width: 18rem; height: 100%;">
          <div class="card-body d-flex flex-column align-items-center justify-content-center p-5">
            <img class="img-fluid rounded-circle" src="portfolio/desktop.jpg" alt="Team Member 1">
            <h5 class="card-title mt-3">Dekstop</h5>
            <p class="card-text">Pembuatan Aplikasi Desktop Berbasis Mac OS</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card" style="width: 18rem; height: 100%;">
          <div class="card-body d-flex flex-column align-items-center justify-content-center p-5">
            <img class="img-fluid rounded-circle" src="portfolio/mobile.jpg" alt="Team Member 2">
            <h5 class="card-title mt-3">Mobile</h5>
            <p class="card-text">Membuat aplikasi berbasis Android</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card" style="width: 18rem; height: 100%;">
          <div class="card-body d-flex flex-column align-items-center justify-content-center p-5">
            <img class="img-fluid rounded-circle" src="portfolio/website.jpg" alt="Team Member 3">
            <h5 class="card-title mt-3">Website</h5>
            <p class="card-text">Membuat website perusahaan</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



<!---Team-->
<div id="Team" class="container-fluid bg-dark">
  <div class="container mt-5 p-5 text-center bg-dark">
    <h3 class="card-subtitle mt-3 mb-5 text-light">Our Team</h3>
    <div class="row text-center">
      <div class="col-md-4">
        <div class="card" style="width: 18rem; height: 100%;">
          <div class="card-body d-flex flex-column align-items-center justify-content-center p-5">
            <img class="img-fluid rounded-circle" src="gambar/gambar 1.png" alt="Team Member 1">
            <h5 class="card-title mt-3">Michael Alanzo</h5>
            <p class="card-text">Full stack Developer</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card" style="width: 18rem; height: 100%;">
          <div class="card-body d-flex flex-column align-items-center justify-content-center p-5">
            <img class="img-fluid rounded-circle" src="gambar/gambar 2.jpg" alt="Team Member 2">
            <h5 class="card-title mt-3">Nicholas Mackenzie</h5>
            <p class="card-text">Mobile App Developer</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card" style="width: 18rem; height: 100%;">
          <div class="card-body d-flex flex-column align-items-center justify-content-center p-5">
            <img class="img-fluid rounded-circle" src="gambar/gambar 3.jpg" alt="Team Member 3">
            <h5 class="card-title mt-3">James Richard</h5>
            <p class="card-text">General Manager</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Contact-->
<section class="contact bg-light">
  <div id="Contact" class="container" data-aos="fade-up">

    <div class="section-title mt-5 p-5 text-dark text-center">
      <h2>Contact</h2>
      <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
    </div>

    <div class="row">
      

      <div class="col-lg-5 d-flex align-items-stretch">
        
        <div class="info">
          <div class="address">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" width="32" height="32" style="float: left; margin-right: 8px;">
              <!--! Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2023 Fonticons, Inc. -->
              <path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"/>
            </svg>
            <h4>Location:</h4>
            <p>AA139, DKI JAKARTA, IND</p>
          </div>

          <div class="email">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="24" height="24" style="float: left; margin-right: 8px;">
              <!--! Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2023 Fonticons, Inc. -->
              <path d="M64 112c-8.8 0-16 7.2-16 16v22.1L220.5 291.7c20.7 17 50.4 17 71.1 0L464 150.1V128c0-8.8-7.2-16-16-16H64zM48 212.2V384c0 8.8 7.2 16 16 16H448c8.8 0 16-7.2 16-16V212.2L322 328.8c-38.4 31.5-93.7 31.5-132 0L48 212.2zM0 128C0 92.7 28.7 64 64 64H448c35.3 0 64 28.7 64 64V384c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V128z"/>
            </svg>
            <h4>Email:</h4>
            <p>info@example.com</p>
          </div>

          <div class="phone">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="24" height="24" style="float: left; margin-right: 8px;">
              <!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
              <path d="M164.9 24.6c-7.7-18.6-28-28.5-47.4-23.2l-88 24C12.1 30.2 0 46 0 64C0 311.4 200.6 512 448 512c18 0 33.8-12.1 38.6-29.5l24-88c5.3-19.4-4.6-39.7-23.2-47.4l-96-40c-16.3-6.8-35.2-2.1-46.3 11.6L304.7 368C234.3 334.7 177.3 277.7 144 207.3L193.3 167c13.7-11.2 18.4-30 11.6-46.3l-40-96z"/>
            </svg>
            <h4>Call:</h4>
            <p>+62 81256789209</p>
          </div>

          <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>
        </div>

      </div>
      <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
        <form action="forms/contact.php" method="post" role="form" class="php-email-form">
          <div class="row">
            <div class="form-group col-md-6">
              <label for="name">Your Name</label>
              <input type="text" name="name" class="form-control" id="name" required>
            </div>
            <div class="form-group col-md-6">
              <label for="name">Your Email</label>
              <input type="email" class="form-control" name="email" id="email" required>
            </div>
          </div>
          <div class="form-group">
            <label for="name">Subject</label>
            <input type="text" class="form-control" name="subject" id="subject" required>
          </div>
          <div class="form-group">
            <label for="name">Message</label>
            <textarea class="form-control" name="message" rows="10" required></textarea>
          </div>
          <div class="my-3">
          </div>
          <a href="https://wa.me/6281385027910?text=Hello%20IT%20Corp,%20I%20have%20a%20question" target="_blank" class="btn btn-success">Kirim Pesan</a>
        </form>
      </div>

    </div>
  </div>
</div>
<!-- ======= Footer ======= -->
<div class="footer-top">
  <div class="container mt-5 p-5 bg-light">
    <div class="row">

      <div class="col-lg-3 col-md-6 footer-contact">
        <h3>IT CORP</h3>
        <p>
          AA139, DKI JAKARTA, IND <br><br>
          <strong>Phone:</strong> +62 81256789209<br>
          <strong>Email:</strong> info@example.com<br>
        </p>
      </div>

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Useful Links</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Layanan Kami</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Mobile</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Desktop</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Sosial Media</h4>
        <p>Cras fermentum odio eu feugiat lide par naso tierra videa magna derita valies</p>
        <div class="social-links mt-3">
          <a href="#" class="twitter"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="24" height="24">
            <!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path d="M459.4 151.7c.3 4.5 .3 9.1 .3 13.6 0 138.7-105.6 298.6-298.6 298.6-59.5 0-114.7-17.2-161.1-47.1 8.4 1 16.6 1.3 25.3 1.3 49.1 0 94.2-16.6 130.3-44.8-46.1-1-84.8-31.2-98.1-72.8 6.5 1 13 1.6 19.8 1.6 9.4 0 18.8-1.3 27.6-3.6-48.1-9.7-84.1-52-84.1-103v-1.3c14 7.8 30.2 12.7 47.4 13.3-28.3-18.8-46.8-51-46.8-87.4 0-19.5 5.2-37.4 14.3-53 51.7 63.7 129.3 105.3 216.4 109.8-1.6-7.8-2.6-15.9-2.6-24 0-57.8 46.8-104.9 104.9-104.9 30.2 0 57.5 12.7 76.7 33.1 23.7-4.5 46.5-13.3 66.6-25.3-7.8 24.4-24.4 44.8-46.1 57.8 21.1-2.3 41.6-8.1 60.4-16.2-14.3 20.8-32.2 39.3-52.6 54.3z"/>
          </svg>
          </a>
          <a href="#" class="facebook"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="24" height="24">
            <!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path d="M512 256C512 114.6 397.4 0 256 0S0 114.6 0 256C0 376 82.7 476.8 194.2 504.5V334.2H141.4V256h52.8V222.3c0-87.1 39.4-127.5 125-127.5c16.2 0 44.2 3.2 55.7 6.4V172c-6-.6-16.5-1-29.6-1c-42 0-58.2 15.9-58.2 57.2V256h83.6l-14.4 78.2H287V510.1C413.8 494.8 512 386.9 512 256h0z"/>
          </svg>
          </a>
          <a href="#" class="instagram"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="24" height="24">
            <!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"/>
          </svg>
          </i></a>
          <a href="#" class="linkedin"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="24" height="24">
            <!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path d="M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.6 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z"/>
          </svg>
          </a>
        </div>
      </div>

    </div>
  </div>
</div>


</footer><!-- End Footer -->

</section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html> 
